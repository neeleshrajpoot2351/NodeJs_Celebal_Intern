const http = require('http');
const fs = require('fs');
const path = require('path');
const server = http.createServer((req, res) => {
    const url = req.url;
    const method = req.method;
    if (url === '/create' && method === 'POST') {
        fs.writeFileSync(path.join(__dirname, 'sample.txt'), 'This is a sample file');
        res.end('File created');
    }
    else if (url === '/read' && method === 'GET') {
        const filePath = path.join(__dirname, 'sample.txt');
        if (fs.existsSync(filePath)) {
            const content = fs.readFileSync(filePath, 'utf8');
            res.end(' File Content: ' + content);
        } else {
            res.end(' File does not exist');
        }
    }
    else if (url === '/delete' && method === 'DELETE') {
        const filePath = path.join(__dirname, 'sample.txt');
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.end('File deleted');
        } else {
            res.end('File not found to delete');
        }
    }
    else {
        res.end('Use /create [POST], /read [GET], or /delete [DELETE]');
    }
});
server.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
