const http = require('http');
const fs = require('fs').promises; 
const path = require('path');

const server = http.createServer(async (req, res) => {
    const { url, method } = req;
    const filePath = path.join(__dirname, 'sample.txt');
    res.setHeader('Content-Type', 'text/plain');

    try {
        if (url === '/create' && method === 'POST') {
            await fs.writeFile(filePath, 'This is a sample file.');
          res.end('File has been created.');
        }

       else if (url === '/read' && method === 'GET') {
            try {
                const content = await fs.readFile(filePath, 'utf8');
                res.end('File content: ' + content);
         } catch (err) {
                if (err.code === 'ENOENT') {
                    res.end('File does not exist.');
                } else {
                    res.end('Error reading the file.');
           }
        }
      }

        else if (url === '/delete' && method === 'DELETE') {
            try {
               await fs.unlink(filePath);
                res.end('File deleted successfully.');
           } catch (err) {
                if (err.code === 'ENOENT') {
                 res.end('No file found to delete.');
                } else {
                    res.end('Error deleting the file.');
              }
            }
        }

        else {
            res.end('Please use /create [POST], /read [GET], or /delete [DELETE]');
        }

    } catch (error) {
        console.error('Something went wrong:', error.message);
        res.statusCode = 500;
        res.end('Internal Server Error');
    }
});

server.listen(3000, () => {
    console.log('Server is running at http://localhost:3000');
});
