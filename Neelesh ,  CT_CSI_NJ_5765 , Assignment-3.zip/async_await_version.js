const fs = require('fs').promises;
const path = require('path');

const filePath = path.join(__dirname, 'sample.txt');

async function createFile() {
    try {
        await fs.writeFile(filePath, 'Sample data');
        console.log('File written');
    } catch (err) {
        console.log('Error writing file');
    }
}

createFile();
