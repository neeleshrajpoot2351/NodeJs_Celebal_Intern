const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'sample.txt');

fs.writeFile(filePath, 'Sample data', (err) => {
    if (err) {
        console.log('Error writing file');
    } else {
        console.log('File written');
    }
});
