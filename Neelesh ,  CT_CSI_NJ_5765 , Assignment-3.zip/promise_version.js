const fs = require('fs').promises;
const path = require('path');

const filePath = path.join(__dirname, 'sample.txt');

fs.writeFile(filePath, 'Sample data')
    .then(() => {
        console.log('File written');
    })
    .catch(() => {
        console.log('Error writing file');
    });
